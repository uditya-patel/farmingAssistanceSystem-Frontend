import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-complaint',
  templateUrl: './update-complaint.component.html',
  styleUrls: ['./update-complaint.component.css']
})
export class UpdateComplaintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
