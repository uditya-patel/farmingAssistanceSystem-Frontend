import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {

  private baseUrl = 'http://localhost:9002';

  constructor(private http: HttpClient) {}

  // getComplaintById(complaintId: number): Observable<any> {
  //   const url = `${this.baseUrl}/admin/viewComplaint`;
  //   return this.http.get<any>(url);
  // }

  GetComplaintById(){
    return this.http.get(`http://localhost:9002/admin/viewComplaint`);
  }


  updateComplaintStatus(complaintId: number, newStatus: string): Observable<any> {
    const url = `${this.baseUrl}/admin/updateComplaint`;
    const body = { status: newStatus };
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    return this.http.put<any>(url, body, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    return new Observable<never>((observer) => {
      observer.error('Something went wrong. Please try again later.');
      observer.complete();
    });
  }


}
