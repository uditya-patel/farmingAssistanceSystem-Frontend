export class User {
<<<<<<< HEAD
    id: number;
    name: string;
    email: string;
    password: string;
    mobile: number;
    address: string;
    gender: string;
    role: string;
    

=======
    userId: number;
	name: string;
	email : string;
	password: string;
	mobile: number;
	role: string;
    address: string;
    gender: string;
>>>>>>> 3a9bd14eb91ab71e224483daf1f5538b5ac26e62
}
