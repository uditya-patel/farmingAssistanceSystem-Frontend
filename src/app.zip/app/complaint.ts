import { User } from "./user";

export class Complaint {
    id: number;
    complaintMessage: string;
    status: string;
    farmer: User;
}
