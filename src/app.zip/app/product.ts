export class Product {
}
