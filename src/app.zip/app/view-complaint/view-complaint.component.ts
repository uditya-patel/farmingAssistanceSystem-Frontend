import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Complaint } from '../complaint';
import { ComplaintService } from '../complaint.service';
import { User } from '../user';

@Component({
  selector: 'app-view-complaint',
  templateUrl: './view-complaint.component.html',
  styleUrls: ['./view-complaint.component.css']
})
export class ViewComplaintComponent implements OnInit {

  complaintId!: number;
  complaints: Complaint[]=[];
  newStatusMap: { [complaintId: number]: string } = {};
  farmer: User;

  
  constructor(
    private route: ActivatedRoute,
    private complaintService: ComplaintService
  ) {}

  ngOnInit(): void {
    this.getcomplaints();
    // this.route.params.subscribe(params => {
    //   this.complaintId = +params['complaintId'];
    //   console.log(this.complaintId);
    //   this.fetchComplaint();
    // });
  }

  // fetchComplaint() {
  //   this.complaintService.GetComplaintById().subscribe(
  //     (data: any) => {
  //       console.log(data);
  //       this.complaints = data;
  //       console.log(this.complaints);
  //     },
  //     (error) => {
  //       console.error('Error fetching complaint:', error);
  //     }
  //   );
  // }

  getcomplaints(){
    this.complaintService.GetComplaintById().subscribe((data:any)=> {
    this.complaints = data;

    for (const complaint of this.complaints) {
      this.newStatusMap[complaint.id] = complaint.status;
    }
    this.farmer = data.farmer;

    console.log(this.complaints);
    console.log(this.farmer);
    })
  }

  updateStatus(complaintId: number) {
    const newStatus = this.newStatusMap[complaintId];
    const complaint = this.complaints.find(c => c.id === complaintId);
    if (complaint) {
      this.complaintService.updateComplaintStatus(complaintId, newStatus).subscribe(
        (data) => {
          complaint.status = newStatus; // Update the status in the list
          // You can add a success message here if required
        },
        (error) => {
          console.error('Error updating status:', error);
          // You can add an error message here if required
        }
      );
    }
  }

}
